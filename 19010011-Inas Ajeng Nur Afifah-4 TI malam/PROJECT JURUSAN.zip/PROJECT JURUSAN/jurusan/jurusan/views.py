from django.shortcuts import render 


def index(request):
    context = {
        'Title' : 'jurusan',
        'Body' : 'list pilihan',}
       
    return render(request,'index.htm', context)