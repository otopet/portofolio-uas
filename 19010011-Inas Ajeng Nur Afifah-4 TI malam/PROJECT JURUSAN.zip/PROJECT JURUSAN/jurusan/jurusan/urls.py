"""jurusan URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from appJurusan.views import index
from django.contrib import admin
from django.urls import path, include
from . import views
from appJurusan.views import *

urlpatterns = [
    path('', views.index),
    path('appJurusan/', include('appJurusan.urls', namespace='jurusan')),
    path('admin/', admin.site.urls),
    path('tambah-pilihan/', tambah_pilihan),
    path('tambah-calon_mahasiswa/', tambah_calonmahasiswa),
    path('pilihan/ubah/<int:id_pilihan>', ubah_pilihan, name='ubah_pilihan'),
    path('calon_mahasiswa/ubah/<int:id_calonmahasiswa>', ubah_calonmahasiswa, name='ubah_calonmahasiswa'),

]
