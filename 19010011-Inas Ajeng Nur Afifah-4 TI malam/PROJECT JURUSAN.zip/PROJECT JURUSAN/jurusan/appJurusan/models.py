from django.db import models
from django.db.models.base import Model
from django.db.models.fields import CharField

# Create your models here.

class pilihan(models.Model):
    PILIHAN_JURUSAN = [
        ('TI','Teknik Informatika'), 
        ('SI','Sistem Informasi'), 
    ]

    No   = models.CharField(max_length=225) 
    Soal = models.CharField(max_length=225)
    Pilihan_A = models.CharField(max_length=225) 
    Pilihan_B = models.CharField(max_length=225) 
    Jawaban_A = models.CharField(max_length=225,choices=PILIHAN_JURUSAN) 
    Jawaban_B = models.CharField(max_length=225, choices=PILIHAN_JURUSAN)


    def __str__(self):
        return self.Soal

class calon_mahasiswa(models.Model):
    JENIS_KELAMIN = [
        ('L','Laki_laki'), 
        ('P','Perempuan'), 
    ]

    NIS = models.CharField(max_length=225,primary_key=True)
    Nama = models.CharField(max_length=225)
    No_HP = models.CharField(max_length=225) 
    Tempat_lahir = models.CharField(max_length=225) 
    Tanggal_lahir = models.DateField()
    Email = models.EmailField(max_length=225)  
    Jenis_Kelamin = models.CharField(max_length=225, choices=JENIS_KELAMIN)


    def __str__(self):
        return self.Nama

class Jawaban(models.Model):
    NIS = models.ForeignKey(calon_mahasiswa,on_delete=models.CASCADE)
    id_soal =  models.ForeignKey(pilihan,on_delete=models.CASCADE)
    pil_jawaban = models.CharField(max_length=225)

    def __int__(self):
        return self.id


