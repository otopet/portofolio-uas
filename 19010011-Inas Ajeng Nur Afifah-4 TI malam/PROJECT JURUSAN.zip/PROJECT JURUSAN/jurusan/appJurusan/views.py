from django.shortcuts import redirect, render
from .models import *
from appJurusan.forms import *
from appJurusan.models import *

def calonmahasiswa(request):
    data_calon_mahasiswa = calon_mahasiswa.objects.all()
    context = {
        'heading':'Calon Mahasiswa',
        'body' :'Daftar Calon Mahasiswa',
        'data' : data_calon_mahasiswa,
    }

    return render(request,'appJurusan/calon_mahasiswa.htm',context)

def pilihan_soal(request):
    data = pilihan.objects.all()
    context = {
        'Title' : 'pilihan',
        'Content' : 'Daftar Pilihan',
        'data' : data,
    }


    return render(request, 'appJurusan/pilihan.htm', context)

def jawaban_soal(request):
    data = Jawaban.objects.all()
    context = {
        'Title' : 'Jawaban',
        'Content' : 'Daftar Jawaban',
        'data' : data,
    }


    return render(request, 'appJurusan/jawaban.htm', context)

def index (request):
    context = {
        'heading':'ini adalah django',
        'body' :'ini django',
    }

    return render(request,'appJurusan/index.htm',context)

def tambah_pilihan(request):
    if request.POST :
        form = Formpilihan(request.POST)
        if form.is_valid():
            form.save()
        return redirect('appJurusan:pilihan')

    else:
        form = Formpilihan()

    context = {
        'form': form,
    }

    return  render(request, 'appJurusan/tambah-pilihan.htm', context)

def tambah_calonmahasiswa(request):
    if request.POST :
        form = Formcalonmahasiswa(request.POST)
        if form.is_valid():
            form.save()
        return redirect('appJurusan:calon_mahasiswa')

    else:
        form = Formcalonmahasiswa()

    context = {
        'form': form,
    }

    return  render(request, 'appJurusan/tambah-calon_mahasiswa.htm', context)

def ubah_calonmahasiswa(request, id_calonmahasiswa):
    calonmahasiswa = calon_mahasiswa.objects.get(NIS=id_calonmahasiswa)
    template = 'ubah-calon_mahasiswa.htm'
    if request.POST:
        form = Formcalonmahasiswa(request.POST, instance=calonmahasiswa)
        if form.is_valid():
            form.save()
        return redirect('ubah_calonmahasiswa', id_calonmahasiswa=id_calonmahasiswa)

    else:
        form = Formcalonmahasiswa(instance=calonmahasiswa)
        context = {
            'form':form,
            'calonmahasiswa': calonmahasiswa,
        }

    return render(request, template, context)

def ubah_pilihan(request, id_pilihan):
    pilihan = pilihan.objects.get(id=id_pilihan)
    template = 'ubah-pilihan.htm'
    if request.POST:
        form = Formpilihan(request.POST, instance=pilihan)
        if form.is_valid():
            form.save()
        return redirect('ubah_pilihan', id_pilihan=id_pilihan)

    else:
        form = Formpilihan(instance=pilihan)
        context = {
            'form':form,
            'pilihan': pilihan,
        }

    return render(request, template, context)

# def list(request):
#     list_pilihan = pilihan.objects.all()
#     context = {
#         'Title' : 'List Pilihan',
#         'Body' : 'List Pilihan',
#         'data' : list_pilihan,
#     } 
#     return render(request,'appJurusan/list.htm', context)


# def updatepilihan(request, update_id):
#     pilihan_update = pilihan.objects.get(id=update_id)
#     pilihan_form = pilihanform(request.POST or None, instance =pilihan_update)

#     if request.method =='POST':

#         if pilihan_form.is_valid():
#             pilihan_form.save()

#             return redirect('appJurusan:listpilihan')

# def deletepilihan (request,delete_id):
#     pilihan_delete = pilihan.objects.get(id=delete_id)
#     pilihan_form = pilihanform(request.POST or None, instance =pilihan_delete)

#     if request.method =='POST':

#         if pilihan_form.is_valid():
#             pilihan_form.save()

#             return redirect('appJurusan:listpilihan')





  


