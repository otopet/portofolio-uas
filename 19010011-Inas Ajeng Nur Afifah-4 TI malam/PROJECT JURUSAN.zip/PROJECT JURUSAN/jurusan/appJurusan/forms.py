from django.forms import ModelForm, widgets
from django import forms
from appJurusan.models import pilihan, calon_mahasiswa

class Formpilihan(ModelForm):
    class Meta:
        model = pilihan 
        fields = '__all__'
    
        widgets = {
            'No' : forms.NumberInput({'class':'form-control'}),
            'Soal' : forms.TextInput({'class':'form-control'}),
            'Pilihan_A' : forms.TextInput({'class':'form-control'}),
            'Pilihan_B' : forms.TextInput({'class':'form-control'}),
            'Jawaban_A' : forms.Select({'class':'form-control'}),
            'Jawaban_B' : forms.Select({'class':'form-control'}),
        }

class Formcalonmahasiswa(ModelForm):
    class Meta:
        model = calon_mahasiswa 
        fields = '__all__'
    
        widgets = {
            'NIS' : forms.NumberInput({'class':'form-control'}),
            'Nama' : forms.TextInput({'class':'form-control'}),
            'No_HP' : forms.NumberInput({'class':'form-control'}),
            'Tempat_lahir' : forms.TextInput({'class':'form-control'}),
            'Tanggal_lahir' : forms.DateInput({'class':'form-control'}),
            'Email' : forms.TextInput({'class':'form-control'}),
            'Jenis_Kelamin' : forms.Select({'class':'form-control'}),
        }