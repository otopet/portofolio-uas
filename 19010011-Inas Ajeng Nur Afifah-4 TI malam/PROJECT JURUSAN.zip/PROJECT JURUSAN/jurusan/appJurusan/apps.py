from django.apps import AppConfig


class AppjurusanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appJurusan'
