from django.urls import path
from . import views
from appJurusan.views import *

app_name = 'appJurusan'
urlpatterns = [
    
    path('', views.index),
    path('calon_mahasiswa/', views.calonmahasiswa, name='calon_mahasiswa'),
    path('pilihan/', views.pilihan_soal, name='pilihan'),
    path('jawaban/', views.jawaban_soal),
    path('tambah-pilihan/', tambah_pilihan),
    path('tambah-calon_mahasiswa/', tambah_calonmahasiswa),
    path('calonmahasiswa/ubah/<int:id_calonmahasiswa>', ubah_calonmahasiswa, name='ubah_calonmahasiswa'),
    path('pilihan/ubah/<int:id_pilihan>', ubah_pilihan, name='ubah_pilihan'),
]
