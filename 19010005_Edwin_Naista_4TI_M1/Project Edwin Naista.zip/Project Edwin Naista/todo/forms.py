from django import forms
from django.forms import fields
from .models import *

class editForm(forms.Form):
    class Meta:
        model = Todo
        fields = ['title']