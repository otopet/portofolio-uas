from django.urls import path

from . import views

urlpatterns = [
    path('',views.index,name='login'),
    path('logout',views.logoutPage,name='logout'),
    path('password/change',views.changePassword,name='changePassword'),
    path('auth/admin',views.admin, name='admin'),
    path('auth/pembimbing',views.pembimbing, name='pembimbing'),
    path('auth/prodi',views.prodi,name='prodi'),
    path('auth/mahasiswa',views.mahasiswa,name='mahasiswa'),
    # Admin
    path('auth/admin/dosen/list',views.listDosen,name='listDosen'),
    path('auth/admin/dosen/add',views.addDosen,name='addDosen'),
    path('auth/admin/dosen/edit=<str:nidn>',views.editDosen,name='editDosen'),
    path('auth/admin/dosen/hapus=<str:nidn>',views.hapusDosen,name='hapusDosen'),
    
    path('auth/admin/mahasiswa/list',views.listMahasiswa,name='listMahasiswa'),
    path('auth/admin/mahasiswa/add',views.addMahasiswa,name='addMahasiswa'),
    path('auth/admin/mahasiswa/edit=<str:npm>',views.editMahasiswa,name='editMahasiswa'),
    path('auth/admin/mahasiswa/hapus=<str:npm>',views.hapusMahasiswa,name='hapusMahasiswa'),
    
    path('auth/admin/registrasi/dosen',views.registrasiDosen,name='registrasiDosen'),
    path('auth/admin/registrasi/mahasiswa',views.registrasiMahasiswa,name='registrasiMahasiswa'),

    path('auth/admin/user/list',views.listUser,name='listUser'),
    path('auth/admin/user/reset=<str:id>user=<str:username>',views.resetUser,name='resetUser'),
    path('auth/admin/user/hapus=<str:id>',views.hapusUser,name='hapusUser'),

    # Mahasiswa
    path('auth/mahasiswa/judul/add',views.addJudul,name='addJudul'),
    path('auth/mahasiswa/judul/edit=<str:id>',views.editJudul,name='editJudul'),
    path('auth/mahasiswa/judul/hapus=<str:id>',views.hapusJudul,name='hapusJudul'),
    path('auth/mahasiswa/judul/hasil',views.hasilJudul,name='hasilJudul'),

    # Dosen Pembimbing
    path('auth/pembimbing/judul/acc=<str:id>',views.accJudul, name='accJudul'),

    # Dosen Prodi
    path('auth/prodi/judul/acc=<str:id>',views.accJudulProdi, name='accJudulProdi'),
    path('auth/prodi/judul/hapus=<str:id>',views.hapusJudulAccProdi,name='hapusJudulAccProdi'),

]