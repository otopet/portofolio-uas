from django.contrib import admin

from .models import *
# Register your models here.
admin.site.register(Dosen)
admin.site.register(Mahasiswa)
admin.site.register(Judul)
admin.site.register(UserApp)