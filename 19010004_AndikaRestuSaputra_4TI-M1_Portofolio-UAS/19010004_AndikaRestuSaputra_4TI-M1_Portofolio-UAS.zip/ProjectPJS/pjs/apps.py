from django.apps import AppConfig


class PjsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pjs'
