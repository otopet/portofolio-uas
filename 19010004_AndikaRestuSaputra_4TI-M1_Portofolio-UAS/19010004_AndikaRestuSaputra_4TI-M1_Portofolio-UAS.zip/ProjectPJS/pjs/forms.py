from django import forms
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import *

class formDosen(ModelForm):
	class Meta:
		model = Dosen
		fields = '__all__'

		widgets = {
			'nidn' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'nama_dosen' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'email' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'no_tlp' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'alamat' : forms.Textarea(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				)
		}

class formMahasiswa(ModelForm):
	class Meta:
		model = Mahasiswa
		fields = '__all__'

		widgets = {
			'npm' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'nama_mahasiswa' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'jurusan' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'semester' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'angkatan' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'email' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'no_tlp' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'alamat' : forms.Textarea(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				)
		}

class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username','email','password1','password2']

class formJudul(ModelForm):
	class Meta:
		model = Judul
		fields = '__all__'

		widgets = {
			'nama_mahasiswa' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'pembimbing_akademik' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'judul' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status_pa' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status_prodi' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'pembimbing_skripsi' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				)
		}

class formAccJudul(ModelForm):
	class Meta:
		model = Judul
		fields = ['nama_mahasiswa','judul','status_pa']

		widgets = {
			'nama_mahasiswa' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'judul' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status_pa' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				)
		}


class formAccJudulProdi(ModelForm):
	class Meta:
		model = Judul
		fields = ['nama_mahasiswa','judul','status_prodi','pembimbing_skripsi']

		widgets = {
			'nama_mahasiswa' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'judul' : forms.TextInput(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'status_prodi' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				),
			'pembimbing_skripsi' : forms.Select(
					attrs={
						'class':'form-control mb-3',
					}
				)
		}