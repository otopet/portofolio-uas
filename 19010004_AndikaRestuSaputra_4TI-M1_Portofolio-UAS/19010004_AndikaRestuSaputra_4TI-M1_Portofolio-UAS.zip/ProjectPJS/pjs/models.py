from django.db import models

# Create your models here.

class Dosen(models.Model):
	STATUS_CHOICES = [
		('active','Active'),
		('nonactive','Nonactive'),
	]

	nidn = models.CharField(primary_key=True, max_length=15)
	nama_dosen = models.CharField(max_length=100)
	email = models.EmailField(max_length=254,null=True,blank=True)
	no_tlp = models.CharField(max_length=13,null=True,blank=True)
	alamat = models.TextField()
	status = models.CharField(max_length=20,choices=STATUS_CHOICES)

	def __str__(self):
		return self.nama_dosen

class Mahasiswa(models.Model):
	STATUS_CHOICES = [
		('active','Active'),
		('nonactive','Nonactive'),
	]

	JURUSAN_CHOICES = [
		('TI','Teknik Informatika'),
		('SI','Sistem Informasi'),
	]

	SEMESTER_CHOICES = [
		('1','Semester 1'),
		('2','Semester 2'),
		('3','Semester 3'),
		('4','Semester 4'),
		('5','Semester 5'),
		('6','Semester 6'),
		('7','Semester 7'),
		('8','Semester 8'),
	]

	npm = models.CharField(primary_key=True, max_length=15)
	nama_mahasiswa = models.CharField(max_length=100)
	jurusan = models.CharField(max_length=50,choices=JURUSAN_CHOICES)
	semester = models.CharField(max_length=15,choices=SEMESTER_CHOICES)
	angkatan = models.CharField(max_length=15,null=True,blank=True)
	email = models.EmailField(max_length=254,null=True,blank=True)
	no_tlp = models.CharField(max_length=13,null=True,blank=True)
	alamat = models.TextField(blank=True)
	status = models.CharField(max_length=20,choices=STATUS_CHOICES)

	def __str__(self):
		return self.nama_mahasiswa

class Judul(models.Model):
	STATUS_CHOICES = [
		('setuju','Setuju'),
		('tolak','Tolak'),
		('revisi','Revisi')
	]

	nama_mahasiswa = models.ForeignKey(Mahasiswa, on_delete=models.CASCADE)
	pembimbing_akademik = models.ForeignKey(Dosen, on_delete=models.CASCADE)
	judul = models.CharField(max_length=255)
	status_pa = models.CharField(max_length=20,choices=STATUS_CHOICES,null=True,blank=True)
	status_prodi = models.CharField(max_length=20,choices=STATUS_CHOICES,null=True,blank=True)
	pembimbing_skripsi = models.CharField(max_length=255,null=True,blank=True)

	def __str__(self):
		return self.judul

class UserApp(models.Model):
	id_user = models.CharField(primary_key=True, max_length=15)
	status = models.CharField(max_length=25,null=True,blank=True)