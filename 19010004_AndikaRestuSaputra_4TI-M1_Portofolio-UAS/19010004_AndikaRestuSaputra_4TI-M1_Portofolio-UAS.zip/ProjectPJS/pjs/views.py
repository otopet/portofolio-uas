from django.shortcuts import render,redirect
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.models import User, Group
from django.contrib.auth import authenticate, login, logout,get_user_model
from django.contrib.auth.decorators import login_required

from .models import *
from .forms import *
# Create your views here.

def index(request):
	if request.method == "POST":
		username = request.POST.get('username')
		password = request.POST.get('password')
		
		group_admin = Group(name="admin")
		group_prodi = Group(name="prodi")
		group_pembimbing = Group(name="pembimbing")
		group_mahasiswa = Group(name="mahasiswa")
		user = authenticate(request, username=username, password=password)
		
		if user is not None:
			if user.groups.filter(name=group_admin):
				login(request,user)
				messages.success(request,'Login berhasil')
				return redirect('admin')
			elif user.groups.filter(name=group_prodi):
				login(request,user)
				messages.success(request,'Login berhasil')
				return redirect('prodi')
			elif user.groups.filter(name=group_pembimbing):
				login(request,user)
				messages.success(request,'Login berhasil')
				return redirect('pembimbing')
			elif user.groups.filter(name=group_mahasiswa):
				login(request,user)
				messages.success(request,'Login berhasil')
				return redirect('mahasiswa')
		else:
			messages.info(request,'Login gagal')

	return render(request,'index.html')

@login_required(login_url='/')
def logoutPage(request):
	logout(request)
	return redirect('login')

@login_required(login_url='/')
def admin(request):
	countDosen = Dosen.objects.filter(status='active').count
	countMahasiswa = Mahasiswa.objects.filter(status='active').count
	countUser = User.objects.all().count

	context = {
		'count_dosen':countDosen,
		'count_mahasiswa':countMahasiswa,
		'count_user':countUser,
	}

	return render(request,'admin.html',context)

@login_required(login_url='/')
def pembimbing(request):

	search_user = request.user.first_name
	if search_user:
		dataJudul = Judul.objects.filter(pembimbing_akademik__nama_dosen = search_user)
		
	context = {
		'data_judul':dataJudul,
	}

	return render(request,'pembimbing.html',context)

@login_required(login_url='/')
def prodi(request):

	search_user = request.GET.get('search')

	if search_user:
		dataJudul = Judul.objects.filter(Q(status_pa__icontains = 'setuju') & Q(nama_mahasiswa__nama_mahasiswa__icontains = search_user))
	else:
		dataJudul = Judul.objects.filter(Q(status_pa__icontains = 'setuju'))

	context = {
		'data_judul':dataJudul,
	}

	return render(request,'prodi.html',context)

@login_required(login_url='/')
def mahasiswa(request):

	search_user = request.user.first_name
	if search_user:
		dataJudul = Judul.objects.filter(nama_mahasiswa__nama_mahasiswa = search_user)
	
	context = {
		'data_judul':dataJudul,
	}

	return render(request,'mahasiswa.html',context)

@login_required(login_url='/')
def registrasiDosen(request):
	if request.method == "POST":
		nama = request.POST.get('name')
		email = request.POST.get('email')
		username = request.POST.get('username')
		password = request.POST.get('password')
		status = request.POST.get('status')

		user = User.objects.create_user(first_name=nama,email=email,username=username,password=password)
		group = Group.objects.get(name=status)
		user.groups.add(group)
		user.save()
		messages.success(request,'User Berhasil Dibuat')

		return redirect('listDosen')
		
@login_required(login_url='/')
def registrasiMahasiswa(request):
	if request.method == "POST":
		nama = request.POST.get('name')
		email = request.POST.get('email')
		username = request.POST.get('username')
		password = request.POST.get('password')
		status = request.POST.get('status')

		user = User.objects.create_user(first_name=nama,email=email,username=username,password=password)
		group = Group.objects.get(name='mahasiswa')
		user.groups.add(group)
		user.save()
		messages.success(request,'User Berhasil Dibuat')

		return redirect('listMahasiswa')

@login_required(login_url='/')
def changePassword(request):
	if request.method == 'POST':
		old_password = request.POST['oldpassword']
		new_password = request.POST['newpassword']
		conf_password = request.POST['confpassword']

		user = User.objects.get(id=request.user.id)
		check_user = user.check_password(old_password)
		if check_user:
			if not new_password == conf_password:
				messages.info(request,'New password dan confirm password tidak cocok')
			else:
				user.set_password(new_password)
				user.save()
				messages.success(request,'Password berhasil diganti')
				return redirect('logout')
		else:
			messages.error(request,'Old password salah')
	return render(request,'changepassword.html')

@login_required(login_url='/')
def resetUser(request,id,username):
		user = User.objects.get(id=id)
		user.set_password(username)
		user.save()
		messages.success(request,'Password berhasil diganti')
		return redirect('listUser')

# List Data
@login_required(login_url='/')
def listDosen(request):

	search_user = request.GET.get('search')

	if search_user:
		dataDosen = Dosen.objects.filter(Q(nama_dosen__icontains = search_user) | Q(nidn__icontains = search_user))
	else:
		dataDosen = Dosen.objects.all().order_by('nama_dosen')
	
	context = {
		'data_dosen':dataDosen,
	}
	return render(request,'listdosen.html',context)


@login_required(login_url='/')
def listMahasiswa(request):
	dataMahasiswa = Mahasiswa.objects.all()
	context = {
		'data_mahasiswa':dataMahasiswa,
	}
	return render(request,'listmahasiswa.html',context)

@login_required(login_url='/')
def listUser(request):
	search_user = request.GET.get('search')

	if search_user:
		dataUser = User.objects.filter(Q(username__icontains = search_user) | Q(first_name__icontains = search_user))
	else:
		dataUser = User.objects.all().order_by('username')
	
	context = {
		'data_user':dataUser,
	}
	return render(request,'listuser.html',context)


# Insert Data 
@login_required(login_url='/')
def addDosen(request):
	form = formDosen()

	if request.method == 'POST':
		form = formDosen(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, 'Data Dosen Berhasil Ditambahkan!.')
			return redirect('listDosen')
			

	context = {
		'form_dosen':form
	}

	return render(request,'formdosen.html',context)

@login_required(login_url='/')
def addMahasiswa(request):
	form = formMahasiswa()

	if request.method == 'POST':
		form = formMahasiswa(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, 'Data Mahasiswa Berhasil Ditambahkan!.')
			return redirect('listMahasiswa')
			
	context = {
		'form_mahasiswa':form
	}

	return render(request,'formmahasiswa.html',context)

@login_required(login_url='/')
def addJudul(request):
	form = formJudul()

	if request.method == 'POST':
		form = formJudul(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, 'Judul Berhasil Ditambahkan!.')
			return redirect('mahasiswa')
			
	context = {
		'form_judul':form
	}

	return render(request,'formjudul.html',context)

# Edit Data
@login_required(login_url='/')
def editDosen(request,nidn):
	get_dosen = Dosen.objects.get(nidn=nidn)
	form = formDosen(instance=get_dosen)

	if request.method == 'POST':
		form = formDosen(request.POST, instance=get_dosen)
		if form.is_valid():
			form.save()
			messages.success(request, 'Data Mahasiswa Berhasil Diubah!')
			return redirect('listDosen')
			

	context = {
		'form_dosen':form
	}

	return render(request,'formdosen.html',context)

@login_required(login_url='/')
def editMahasiswa(request,npm):
	get_mahasiswa = Mahasiswa.objects.get(npm=npm)
	form = formMahasiswa(instance=get_mahasiswa)

	if request.method == 'POST':
		form = formMahasiswa(request.POST, instance=get_mahasiswa)
		if form.is_valid():
			form.save()
			messages.success(request, 'Data Mahasiswa Berhasil Diubah!')
			return redirect('listMahasiswa')
			

	context = {
		'form_mahasiswa':form
	}

	return render(request,'formmahasiswa.html',context)

@login_required(login_url='/')
def editJudul(request,id):
	get_judul = Judul.objects.get(id=id)
	form = formJudul(instance=get_judul)

	if request.method == 'POST':
		form = formJudul(request.POST, instance=get_judul)
		if form.is_valid():
			form.save()
			messages.success(request, 'Judul Berhasil Diubah!')
			return redirect('mahasiswa')
			

	context = {
		'form_judul':form
	}

	return render(request,'formjudul.html',context)

@login_required(login_url='/')
def accJudul(request,id):
	get_judul = Judul.objects.get(id=id)
	form = formAccJudul(instance=get_judul)

	if request.method == 'POST':
		form = formAccJudul(request.POST, instance=get_judul)
		if form.is_valid():
			print(form.save())
			messages.success(request, 'Judul Berhasil Diubah!')
			return redirect('pembimbing')

	context = {
		'form_judul':form,
	}

	return render(request,'accjudul.html',context)

@login_required(login_url='/')
def accJudulProdi(request,id):
	get_dosen = Dosen.objects.all()
	get_judul = Judul.objects.get(id=id)
	form = formAccJudulProdi(instance=get_judul)

	if request.method == 'POST':
		form = formAccJudulProdi(request.POST, instance=get_judul)
		if form.is_valid():
			print(form.save())
			messages.success(request, 'Judul Berhasil Diubah!')
			return redirect('prodi')

	context = {
		'form_judul':form,
		'data_dosen':get_dosen
	}

	return render(request,'accjudulprodi.html',context)


# Delete Data
@login_required(login_url='/')
def hapusDosen(request,nidn):
	get_dosen = Dosen.objects.get(nidn=nidn)
	get_dosen.delete()
	messages.success(request, 'Data Dosen Berhasil Dihapus!')
	return redirect('listDosen')

@login_required(login_url='/')
def hapusMahasiswa(request,npm):
	get_mahasiswa = Mahasiswa.objects.get(npm=npm)
	get_mahasiswa.delete()
	messages.success(request, 'Data Mahasiswa Berhasil Dihapus!')
	return redirect('listMahasiswa')

@login_required(login_url='/')
def hapusJudul(request,id):
	get_judul = Judul.objects.get(id=id)
	get_judul.delete()
	messages.success(request, 'Judul Berhasil Dihapus!')
	return redirect('mahasiswa')

@login_required(login_url='/')
def hapusJudulAccProdi(request,id):
	get_judul = Judul.objects.get(id=id)
	get_judul.delete()
	messages.success(request, 'Judul Berhasil Dihapus!')
	return redirect('prodi')

@login_required(login_url='/')
def hapusUser(request,id):
	get_user = User.objects.get(id=id)
	get_user.delete()
	messages.success(request, 'User Berhasil Dihapus!')
	return redirect('listUser')

# Hasil judul
@login_required(login_url='/')
def hasilJudul(request):
	search_user = request.user.first_name
	if search_user:
		dataJudul = Judul.objects.filter(Q(nama_mahasiswa__nama_mahasiswa = search_user) & Q(status_pa = 'setuju') & Q(status_prodi = 'setuju'))
	
	context = {
		'data_judul':dataJudul,
	}

	return render(request,'hasiljudul.html',context)