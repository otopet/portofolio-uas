var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl);
});

let form = document.querySelector(".needs-validation");
form.addEventListener("submit", valid);

function valid(e) {
  if (form.checkValidity() == false) {
    e.preventDefault();
  }
  form.classList.add("was-validated");
}
